using Terraria.ModLoader;

namespace Fear
{
	class Fear : Mod
	{
		public Fear()
		{
		}
	}
}
